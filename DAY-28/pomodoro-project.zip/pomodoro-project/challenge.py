from tkinter import *

# ---------------------------- CONSTANTS ------------------------------- #
RED = "#FF8787"
PEACH = "#F8C4B4"
LIGHT_GREEN = "#E5EBB2"
GREEN = "#BCE29E"
FONT_NAME = "Pacifico"
WORK_MIN = 25
SHORT_BREAK_MIN = 5
LONG_BREAK_MIN = 20


# ---------------------------- TIMER RESET ------------------------------- #

# ---------------------------- TIMER MECHANISM ------------------------------- #

# ---------------------------- COUNTDOWN MECHANISM ------------------------------- #

# ---------------------------- UI SETUP ------------------------------- #
